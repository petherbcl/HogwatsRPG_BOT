
module.exports = function (client) {
}